﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CommonLibrary
{
    public class Notiz
    {
        public int ID { get; set; }
        public string NOTIZID { get; set; } = string.Empty;
        public string Tulajdonos { get; set; } = string.Empty;
        public string Feladat { get; set; } = string.Empty;
        public string Allapot { get; set; } = string.Empty;
        public string MikorKezdje { get; set; } = string.Empty;
        public string HatarIdo { get; set; } = string.Empty;
        public string FOntossag { get; set; } = string.Empty;
        public string Komment { get; set; } = string.Empty;
        public string ProjektNev { get; set; } = string.Empty;


    }
}
